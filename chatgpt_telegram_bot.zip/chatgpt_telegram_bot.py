import openai
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, ContextTypes, filters

# 🔐 Keys (keep them private and secure)
OPENAI_API_KEY = "sk-admin...xyz"  # <-- replace with your real API key
TELEGRAM_BOT_TOKEN = "7846607191:AAFLndtmaEf1IUQ20iSahbn02LbMXLiBw-k"

# 🔌 Configure OpenAI
openai.api_key = OPENAI_API_KEY

# 🤖 Reply handler
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_message = update.message.text

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": user_message}]
        )
        reply = response['choices'][0]['message']['content']
    except Exception as e:
        reply = "⚠️ Error: " + str(e)

    await update.message.reply_text(reply)

# 🚀 Bot start
app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), handle_message))

print("✅ Bot is running... Open Telegram and talk to it!")
app.run_polling()